July 22, 2011

The controlled terminology in this spreadsheet supports Study Data Tabulation Model 
Implementation Guide Version 3.1.2 (SDTMIG v3.1.2). It represents all SDTM controlled 
terminology developed and in production to date. This version is a complete list of 
all controlled terminology used for both SDTM and CDASH. Additional terminology will 
be developed on an ongoing basis to support all CDISC standards. Other future additions 
to the v3.1.2 terminology set will be handled via the terminology change request and 
maintenance process. As of the publication on 2010-04-08, the CDISC Preferred Term 
column (formerly Column F) was removed. It was determined that this column was redundant 
and confusing to most implementers. Column F now contains CDISC synonyms.

The May 1, 2009 release brought changes to the SDTM data files -- notably,
dropping columns J & K -- as noted in the ReadMe file and Excel tab.  A new pair
of change description files provide detailed descriptions of all terminology
changes, including change request tracking numbers and release dates.

The March 8, 2010 release brought changes to the SDTM data files -- notably, the
addition of a controlled terminology subset of SDTM terminology corresponding to
the Clinical Data Acquisition Standards Harmonization Standard 1.0 (CDASH STD
1.0) Appendix A, a listing of commonly used CDISC controlled terminology within
the CDASH standard.

Contents:

Archive                       	(directory for earlier file versions)
CDASH CDISC ReadME.doc	      	ReadMe tab in CDASH terminology file, doc format
CDASH Publication Date Stamp.txtinformation regarding current version date of CDASH terminology
CDASH Terminology Changes.xls  	detailed description of term changes (Excel)
CDASH Terminology Changes.txt  	detailed description of term changes (text)
                                (same as "Changes" tab in Excel file)
CDASH Terminology.OWL.zip	terms by codelist, OWL/RDF format
CDASH Terminology.html		terms by codelist, HTML format
CDASH Terminology.odm.xml	terms by codelist, ODM XML format
CDASH Terminology.pdf		terms by codelist, PDF format
CDASH Terminology.txt         	terms by codelist, text format
CDASH Terminology.xls	     	terms by codelist, Excel format
ReadMe.txt                    	(this file)
SDTM CDISC ReadMe.doc         	Copy of Excel ReadMe tab in Word format
SDTM Publication Date Stamp.txt	information regarding current version date of SDTM terminology
SDTM Terminology Changes.xls  	detailed description of term changes (Excel)
SDTM Terminology Changes.txt  	detailed description of term changes (text)
                                (same as "Changes" tab in Excel file)
SDTM Terminology.OWL.zip	terms by codelist, OWL/RDF format
SDTM Terminology.html		terms by codelist, HTML format
SDTM Terminology.odm.xml	terms by codelist, ODM XML format
SDTM Terminology.pdf		terms by codelist, PDF format
SDTM Terminology.txt          	terms by codelist, text format (omits column 'K: Notes')
SDTM Terminology.xls          	terms by codelist, Excel format


Background:

SDTM is an international standard for clinical research data, and is approved
by the U.S. Food and Drug Administration as a standard electronic submission
format.  CDISC and NCI work together to develop and maintain SDTM controlled
terminology, which is also integrated and distributed as part of NCI
Thesaurus (NCIt).

Further information is available at:
     http://www.cancer.gov/cancertopics/terminologyresources/CDISC



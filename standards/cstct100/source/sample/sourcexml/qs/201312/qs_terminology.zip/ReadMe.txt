June 29, 2012

The controlled terminology in this spreadsheet supports Questionnaire terminology 
for the current versions of the Study Data Tabulation Model Implementation Guide 
and the Clinical Data Acquisition Standards Harmonization. It represents all 
Questionnaire controlled terminology developed and in production to date. This 
version is a complete list of all controlled terminology used for both SDTM and CDASH. 
Additional terminology will be developed on an ongoing basis to support all CDISC 
standards. Future additions to the terminology set is handled via the terminology 
change request and maintenance process. 

Contents:

Archive                       		(directory for earlier file versions)
QS CDISC ReadMe.doc         		Copy of Excel ReadMe tab in Word format
QS Publication Date Stamp.txt		information regarding current version date of QS terminology
QS Terminology Changes.txt		detailed description of term changes (text)
QS Terminology Changes.xls		detailed description of term changes (Excel)
QS Terminology.OWL.zip			terms by codelist, OWL/RDF format
QS Terminology.html			terms by codelist, HTML format
QS Terminology.odm.xml			terms by codelist, ODM XML format
QS Terminology.pdf			terms by codelist, PDF format
QS Terminology.txt          		terms by codelist, text format
QS Terminology.xls          		terms by codelist, Excel format
ReadMe.txt                    		(this file)


Background:

SDTM and CDASH are international standards for clinical research data collection 
and submission, and are approved by the U.S. Food and Drug Administration as a 
standard electronic submission format. CDISC and NCI work together to develop 
and maintain SDTM controlledterminology, which is also integrated and distributed 
as part of NCIThesaurus (NCIt).

Further information is available at:
     http://www.cancer.gov/cancertopics/terminologyresources/CDISC



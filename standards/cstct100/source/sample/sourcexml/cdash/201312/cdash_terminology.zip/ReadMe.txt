July 22, 2011

This directory contains data files and documentation for controlled terminology
used by the Clinical Data Interchange Standards Consortium (CDISC) to support
Standard for the Exchange of Nonclinical Data Implementation Guide Version 3.0 
(SENDIG V3.0). It represents all SEND controlled terminology developed and in 
production to date as well as specific SDTM codelists that are in production to 
date. Additional terminology will be developed on an ongoing basis to support 
all CDISC standards. Other future additions to the SEND terminology set will be 
handled via the terminology change request and maintenance process.


Contents:

Archive                       	(directory for earlier file versions)
ReadMe.txt			(this file)
SEND CDISC ReadME.doc	      	ReadMe tab in CDASH terminology file, doc format
SEND Publication Date Stamp.txt	information regarding current version date of SEND terminology
SEND Terminology Changes.txt	detailed description of term changes (text)
SEND Terminology Changes.xls	detailed description of term changes (Excel)
SEND Terminology.OWL.zip	terms by codelist, OWL/RDF format
SEND Terminology.html		terms by codelist, HTML format
SEND Terminology.odm.xml	terms by codelist, ODM XML format
SEND Terminology.pdf		terms by codelist, PDF format
SEND Terminology.txt         	terms by codelist, text format
SEND Terminology.xls	     	terms by codelist, Excel format




Background:

SEND is an international standard for nonclinical research data, and is approved
by the U.S. Food and Drug Administration as a standard electronic submission
format.  CDISC and NCI work together to develop and maintain SDTM controlled
terminology, which is also integrated and distributed as part of NCI
Thesaurus (NCIt).

Further information is available at:
     http://www.cancer.gov/cancertopics/terminologyresources/CDISC

